# Databricks notebook source
# MAGIC %run ./00_setup

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

display(spark.table("bronze.customers"))

# COMMAND ----------

#clean customers data
customers = (
    spark.table("bronze.customers")
    .select(
        F.trim("customer_id").alias("customer_id"),
        F.initcap(F.trim("first_name")).alias("first_name"),
        F.initcap(F.trim("last_name")).alias("last_name"),
        F.lower(F.trim("email")).alias("email"),
        F.initcap(F.trim("city")).alias("city"),
        F.initcap(F.trim("state")).alias("state"),
        F.to_date("signup_date").alias("signup_date"),
        F.initcap(F.trim("loyalty_tier")).alias("loyalty_tier")
    )
    .dropDuplicates(["customer_id"])
)

# COMMAND ----------

#write it to silver
customers.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("silver.customers")

# COMMAND ----------

display(spark.table("silver.customers"))

# COMMAND ----------

#clean products,write it to silver,display
products = (
    spark.table("bronze.products")
    .select(
        F.trim("product_id").alias("product_id"),
        F.trim("product_name").alias("product_name"),
        F.trim("category").alias("category"),
        F.trim("brand").alias("brand"),
        F.col("unit_price").cast("decimal(10,2)").alias("unit_price"),
        F.col("stock_quantity").cast("int").alias("stock_quantity"),
        (F.col("is_active") == "true").alias("is_active")
    )
    .dropDuplicates(["product_id"])
)
products.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("silver.products")
display(spark.table("silver.products"))

# COMMAND ----------

#Flatten the Orders JSON
order_lines = (
    spark.table("bronze.orders")
    .select(
        "order_id",
        F.to_date("order_date").alias("order_date"),
        "customer_id",
        "payment_method",
        "order_status",
        F.col("shipping_address.city").alias("ship_city"),
        F.col("shipping_address.state").alias("ship_state"),
        F.col("shipping_address.pincode").alias("ship_pincode"),
        F.explode("items").alias("item")
    )
)

# COMMAND ----------

display(order_lines)

# COMMAND ----------

#extract the item fields
order_lines = (
    order_lines
    .select(
        "order_id",
        "order_date",
        "customer_id",
        "payment_method",
        "order_status",
        "ship_city",
        "ship_state",
        "ship_pincode",
        F.col("item.product_id").alias("product_id"),
        F.col("item.quantity").cast("int").alias("quantity"),
        F.col("item.discount_pct").cast("int").alias("discount_pct")
    )
)
display(order_lines)

# COMMAND ----------

#save it as silver and display
order_lines.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("silver.order_lines")
display(spark.table("silver.order_lines"))

# COMMAND ----------

#data quality checks
c = spark.table("silver.customers")
p = spark.table("silver.products")
o = spark.table("silver.order_lines")

# COMMAND ----------

#check 1-null customer id
print("null customer ids :",c.filter("customer_id is null").count())

# COMMAND ----------

#check 2-null product ids
print("null product ids :",p.filter("product_id is null").count())

# COMMAND ----------

#check 3- invalid quantities
"bad quantity :",o.filter("quantity <= 0").count()

# COMMAND ----------

#check 4: invalid discounts
print("bad discounts :",o.filter("discount_pct < 0 or discount_pct > 100").count())

# COMMAND ----------

#check 5: orders with customers that don't exist 
print("orphan customers:",o.join(c,"customer_id","left_anti").count())

# COMMAND ----------

#check 6- orders with products that don't exist 
print("orphan products:",o.join(p,"product_id","left_anti").count())