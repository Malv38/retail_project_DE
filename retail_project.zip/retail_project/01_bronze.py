# Databricks notebook source
# MAGIC %run ./00_setup

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

#Read your three source files into Spark DataFrames
#create 3 dataframes- customers,products,orders
customers = spark.read.option("header", True).csv(f"{base}/customers.csv")

# COMMAND ----------

products = spark.read \
    .option("header", True) \
    .csv(f"{base}/products.csv")

# COMMAND ----------

orders = spark.read \
    .option("multiLine", True) \
    .json(f"{base}/orders.json")

# COMMAND ----------

#Add the Bronze audit columns
#create 3 dataframes for bronze layer using the older dataframes with audit column

def add_audit(df, filename):
    return (
        df.withColumn("_ingest_time", F.current_timestamp())
          .withColumn("_source_file", F.lit(filename))
    )
customers_bronze = add_audit(
    customers,
    "customers.csv"
)

products_bronze = add_audit(
    products,
    "products.csv"
)

orders_bronze = add_audit(
    orders,
    "orders.json"
)

# COMMAND ----------

#Save them as Bronze Delta tables
customers_bronze.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("bronze.customers")

products_bronze.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("bronze.products")

orders_bronze.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("bronze.orders")

# COMMAND ----------

#verify bronze
print("customers:", spark.table("bronze.customers").count())
print("products:", spark.table("bronze.products").count())
print("orders:", spark.table("bronze.orders").count())

# COMMAND ----------

display(spark.table("bronze.customers"))

# COMMAND ----------

display(spark.table("bronze.products"))

# COMMAND ----------

display(spark.table("bronze.orders"))