# Databricks notebook source
# MAGIC %run ./00_setup

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %md
# MAGIC The Gold layer turns the cleaned Silver data into business-ready tables:
# MAGIC
# MAGIC gold.fact_sales — main sales table, 
# MAGIC gold.monthly_revenue_by_category, 
# MAGIC gold.top_customers, 
# MAGIC gold.revenue_by_state, 
# MAGIC gold.product_rank_by_category, 
# MAGIC gold.order_status_summary

# COMMAND ----------

#create gold.fact_sales table
order_lines = spark.table("silver.order_lines")
products = spark.table("silver.products")
customers = spark.table("silver.customers")

fact_sales = (
    order_lines
    .join(products, "product_id", "left")
    .join(customers, "customer_id", "left")
    .withColumn(
        "line_revenue",
        F.col("unit_price") *
        F.col("quantity") *
        (1 - F.col("discount_pct") / 100)
    )
    .withColumn("year", F.year("order_date"))
    .withColumn("month", F.month("order_date"))
)

fact_sales.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("gold.fact_sales")

# COMMAND ----------

display(spark.table("gold.fact_sales"))

# COMMAND ----------

#monthly revenue by category table creation
monthly_revenue_by_category = (
    spark.table("gold.fact_sales")
    .groupBy("year", "month", "category")
    .agg(
        F.sum("line_revenue").alias("total_revenue")
    )
    .orderBy("year", "month", "category")
)

monthly_revenue_by_category.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("gold.monthly_revenue_by_category")

display(spark.table("gold.monthly_revenue_by_category"))

# COMMAND ----------

#gold.top_customers table creation
top_customers = (
    spark.table("gold.fact_sales")
    .groupBy("customer_id", "first_name", "last_name")
    .agg(
        F.sum("line_revenue").alias("total_revenue")
    )
    .orderBy(F.desc("total_revenue"))
)

top_customers.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("gold.top_customers")

display(spark.table("gold.top_customers"))

# COMMAND ----------

#gold.revenue_by_state table creation
revenue_by_state = (
    spark.table("gold.fact_sales")
    .groupBy("state")
    .agg(
        F.sum("line_revenue").alias("total_revenue")
    )
    .orderBy(F.desc("total_revenue"))
)

revenue_by_state.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("gold.revenue_by_state")

display(spark.table("gold.revenue_by_state"))

# COMMAND ----------

#gold.product_rank_by_category
from pyspark.sql.window import Window
product_rank_by_category = (
    spark.table("gold.fact_sales")
    .groupBy("category", "product_id", "product_name")
    .agg(
        F.sum("line_revenue").alias("total_revenue")
    )
    .withColumn(
        "rank",
        F.row_number().over(
            Window.partitionBy("category")
                  .orderBy(F.desc("total_revenue"))
        )
    )
    .orderBy("category", "rank")
)

product_rank_by_category.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("gold.product_rank_by_category")

display(spark.table("gold.product_rank_by_category"))

# COMMAND ----------

#gold.order_status_summary table creation
order_status_summary = (
    spark.table("gold.fact_sales")
    .groupBy("order_status")
    .agg(
        F.countDistinct("order_id").alias("order_count"),
        F.sum("line_revenue").alias("total_revenue")
    )
    .orderBy(F.desc("order_count"))
)

order_status_summary.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("gold.order_status_summary")

display(spark.table("gold.order_status_summary"))

# COMMAND ----------

#check if all gold tables exist
spark.sql("SHOW TABLES IN gold").show()

# COMMAND ----------

#check the main fact table
display(spark.table("gold.fact_sales"))

# COMMAND ----------

#to check row counts 
print("fact_sales:", spark.table("gold.fact_sales").count())
print("monthly_revenue_by_category:", spark.table("gold.monthly_revenue_by_category").count())
print("top_customers:", spark.table("gold.top_customers").count())
print("revenue_by_state:", spark.table("gold.revenue_by_state").count())
print("product_rank_by_category:", spark.table("gold.product_rank_by_category").count())
print("order_status_summary:", spark.table("gold.order_status_summary").count())

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold.fact_sales
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold.monthly_revenue_by_category
# MAGIC ORDER BY year, month;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gold.top_customers
# MAGIC ORDER BY total_revenue DESC
# MAGIC LIMIT 10;

# COMMAND ----------

