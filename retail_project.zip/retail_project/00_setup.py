# Databricks notebook source
storage_account = "storageaccmal"
container="source"

client_id = dbutils.secrets.get(
    scope="databrickscope",
    key="clientid"
)

client_secret = dbutils.secrets.get(
    scope="databrickscope",
    key="clientsecret"
)

tenant_id = dbutils.secrets.get(
    scope="databrickscope",
    key="tenantid"
)

host = f"{storage_account}.dfs.core.windows.net"

spark.conf.set(
    f"fs.azure.account.auth.type.{host}",
    "OAuth"
)

spark.conf.set(
    f"fs.azure.account.oauth.provider.type.{host}",
    "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider"
)

spark.conf.set(
    f"fs.azure.account.oauth2.client.id.{host}",
    client_id
)

spark.conf.set(
    f"fs.azure.account.oauth2.client.secret.{host}",
    client_secret
)

spark.conf.set(
    f"fs.azure.account.oauth2.client.endpoint.{host}",
    f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
)

# COMMAND ----------

base = f"abfss://source@{host}"

# COMMAND ----------

spark.sql("CREATE SCHEMA IF NOT EXISTS bronze")
spark.sql("CREATE SCHEMA IF NOT EXISTS silver")
spark.sql("CREATE SCHEMA IF NOT EXISTS gold")

# COMMAND ----------

display(dbutils.fs.ls(base))